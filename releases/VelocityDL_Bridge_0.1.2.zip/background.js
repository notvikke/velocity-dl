import { shouldRejectWeakScanCapture } from "./capture-routing.js";
import { chooseResolvedScanCapture } from "./scan-capture-choice.js";
import { DEFAULT_SCAN_CAPTURE_MODE, normalizeScanCaptureMode } from "./scan-capture-mode.js";
import { shouldReinjectScanOverlay } from "./scan-overlay-state.js";
import { buildBrowserTakeoverHeaders } from "./takeover-session.js";
import {
  RequestContextStore,
  mergeSessionCookies,
  sanitizeRequestHeaders,
} from "./request-context.js";
import { MediaCandidateStore } from "./media-observer-core.js";
import { NativeTransport } from "./native-transport.js";
import { scorePlayableCandidate } from "./playable-candidate.js";

const NATIVE_HOST = "com.velocitydl.native_host";
const HEARTBEAT_ALARM = "vdlExtensionHeartbeat";
const SESSION_REFRESH_ALARM = "vdlSessionRefresh";
const HEARTBEAT_PERIOD_MINUTES = 5;

const DEFAULT_SETTINGS = {
  takeoverAllDownloads: true,
  showContextMenu: true,
  scanCaptureMode: DEFAULT_SCAN_CAPTURE_MODE,
};
let menuRebuildQueue = Promise.resolve();
const WEBREQUEST_CAPTURE_DEDUPE_WINDOW_MS = 90_000;
const recentWebRequestCaptures = new Map();
const RECENT_PLAYABLE_BY_TAB_WINDOW_MS = 30 * 60_000;
const recentPlayableByTab = new Map();
const ACTIVE_SCAN_TABS_KEY = "activeScanTabs";
const LAST_SCAN_DEBUG_KEY = "lastScanDebug";
const LAST_HEARTBEAT_DEBUG_KEY = "lastHeartbeatDebug";
const pendingBrowserDownloads = new Map();
const requestContextStore = new RequestContextStore();
const observedMediaStore = new MediaCandidateStore();
const nativeTransport = new NativeTransport({
  connect: () => chrome.runtime.connectNative(NATIVE_HOST),
  maxInFlight: 8,
  timeoutMs: 90_000,
});
const DOWNLOADABLE_FILE_EXT_RE =
  /\.(exe|msi|msix|msixbundle|appx|appxbundle|zip|rar|7z|tar|gz|bz2|xz|iso|img|dmg|pkg|deb|rpm|apk|ipa|jar|pdf|doc|docx|xls|xlsx|ppt|pptx|csv|json|xml|txt|rtf|epub)(?:$|[?#])/i;

function safeOrigin(url) {
  try {
    return new URL(url).origin;
  } catch {
    return "";
  }
}

function parseUrlParts(url) {
  try {
    const parsed = new URL(url);
    return {
      href: parsed.href,
      host: parsed.hostname.toLowerCase(),
      path: parsed.pathname.toLowerCase(),
    };
  } catch {
    return null;
  }
}

async function getActiveScanTabs() {
  const data = await chrome.storage.session.get(ACTIVE_SCAN_TABS_KEY);
  const raw = data?.[ACTIVE_SCAN_TABS_KEY];
  return Array.isArray(raw) ? raw.filter((id) => Number.isInteger(id) && id >= 0) : [];
}

async function isScanActiveForTab(tabId) {
  if (!Number.isInteger(tabId) || tabId < 0) return false;
  const activeTabs = await getActiveScanTabs();
  return activeTabs.includes(tabId);
}

async function setScanActiveForTab(tabId, active) {
  if (!Number.isInteger(tabId) || tabId < 0) return;
  const activeTabs = new Set(await getActiveScanTabs());
  if (active) activeTabs.add(tabId);
  else activeTabs.delete(tabId);
  await chrome.storage.session.set({ [ACTIVE_SCAN_TABS_KEY]: [...activeTabs] });
}

async function applyScanStateToTab(tabId, active, frameId) {
  if (!Number.isInteger(tabId) || tabId < 0) return;
  const frameIds = Number.isInteger(frameId) && frameId >= 0
    ? [frameId]
    : await chrome.webNavigation
        .getAllFrames({ tabId })
        .then((frames) =>
          Array.isArray(frames) && frames.length
            ? frames.map((frame) => frame.frameId)
            : [0]
        )
        .catch(() => [0]);

  await Promise.all(
    frameIds.map(async (targetFrameId) => {
      try {
        await chrome.tabs.sendMessage(
          tabId,
          { type: "vdl_scan_set_active", active: !!active },
          { frameId: targetFrameId }
        );
      } catch (initialError) {
        if (!shouldReinjectScanOverlay(initialError)) {
          console.warn("[VelocityDL] Failed to apply scan state:", initialError);
          return;
        }

        try {
          await chrome.scripting.executeScript({
            target: { tabId, frameIds: [targetFrameId] },
            files: ["scan-overlay.js"],
          });
          await chrome.tabs.sendMessage(
            tabId,
            { type: "vdl_scan_set_active", active: !!active },
            { frameId: targetFrameId }
          );
        } catch (retryError) {
          console.warn("[VelocityDL] Failed to re-inject scan overlay:", retryError);
        }
      }
    })
  );
}

async function clearScanStateOnTab(tabId) {
  try {
    await applyScanStateToTab(tabId, false);
  } finally {
    await setScanActiveForTab(tabId, false);
  }
}

async function initializeActiveScanTabs() {
  const activeTabs = await getActiveScanTabs();
  if (!activeTabs.length) return;
  await Promise.all(
    activeTabs.map(async (tabId) => {
      try {
        const tab = await chrome.tabs.get(tabId);
        if (!tab?.id || !/^https?:\/\//i.test(tab.url || "")) {
          await clearScanStateOnTab(tabId);
        }
      } catch {
        await clearScanStateOnTab(tabId);
      }
    })
  );
}

async function getSettings() {
  const data = await chrome.storage.local.get(DEFAULT_SETTINGS);
  return {
    ...DEFAULT_SETTINGS,
    ...data,
    scanCaptureMode: normalizeScanCaptureMode(data.scanCaptureMode, data),
  };
}

function removeAllContextMenus() {
  return new Promise((resolve) => {
    chrome.contextMenus.removeAll(() => resolve());
  });
}

function createContextMenu(item) {
  return new Promise((resolve) => {
    chrome.contextMenus.create(item, () => {
      // Ignore duplicate/no-op create races during worker wakeups.
      if (chrome.runtime.lastError) {
        const msg = chrome.runtime.lastError.message || "";
        if (!msg.includes("duplicate id")) {
          console.warn("[VelocityDL] context menu create error:", msg);
        }
      }
      resolve();
    });
  });
}

function removeContextMenu(id) {
  return new Promise((resolve) => {
    chrome.contextMenus.remove(id, () => {
      // It's fine if the item does not exist yet.
      if (chrome.runtime.lastError) {
        const msg = chrome.runtime.lastError.message || "";
        if (!msg.includes("Cannot find menu item")) {
          console.warn("[VelocityDL] context menu remove error:", msg);
        }
      }
      resolve();
    });
  });
}

async function rebuildContextMenus(enabled) {
  await removeAllContextMenus();
  if (!enabled) return;

  // Extra safety for Chromium forks: remove by id before create.
  await removeContextMenu("vdl-download-link");
  await removeContextMenu("vdl-download-page");
  await removeContextMenu("vdl-download-media");

  await createContextMenu({
    id: "vdl-download-link",
    title: "Download with VelocityDL",
    contexts: ["link"],
  });
  await createContextMenu({
    id: "vdl-download-page",
    title: "Download Page URL with VelocityDL",
    contexts: ["page"],
  });
  await createContextMenu({
    id: "vdl-download-media",
    title: "Download Media with VelocityDL",
    contexts: ["video", "audio"],
  });
}

function queueRebuildContextMenus(enabled) {
  menuRebuildQueue = menuRebuildQueue
    .then(() => rebuildContextMenus(enabled))
    .catch((err) => console.warn("[VelocityDL] context menu rebuild failed:", err));
}

function shouldHandleUrl(url) {
  if (!url || typeof url !== "string") return false;
  if (!/^https?:\/\//i.test(url)) return false;
  if (url.startsWith("https://chrome.google.com/webstore")) return false;
  if (url.startsWith("https://chromewebstore.google.com/")) return false;
  return true;
}

function isLikelyDirectMediaUrl(url) {
  if (!url || typeof url !== "string") return false;
  const parts = parseUrlParts(url);
  if (!parts) return false;
  return /\.(mp4|mkv|webm|mov|m4v|mp3|m4a|aac|flac|wav|ogg|opus|m3u8|mpd|ts|m4s|weba)$/i.test(
    parts.path
  );
}

function isLikelyDownloadableFileUrl(url) {
  if (!url || typeof url !== "string") return false;
  const parts = parseUrlParts(url);
  if (!parts) return false;
  return DOWNLOADABLE_FILE_EXT_RE.test(parts.path);
}

function filenameLooksDownloadable(filename) {
  return typeof filename === "string" && DOWNLOADABLE_FILE_EXT_RE.test(filename.trim());
}

function isLikelySegmentUrl(url) {
  if (!url || typeof url !== "string") return false;
  return (
    /\.(m4s|ts|cmfv|cmfa|fmp4)(?:$|[?#])/i.test(url) ||
    /(?:^|[/?&])(chunk|segment|frag|fragment|sq|range)=/i.test(url)
  );
}

function isLikelyManifestUrl(url) {
  if (!url || typeof url !== "string") return false;
  const parts = parseUrlParts(url);
  if (!parts) return false;
  return /\.(m3u8|mpd)$/i.test(parts.path);
}

function isYouTubePageUrl(url) {
  if (!url || typeof url !== "string") return false;
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    return (
      host === "youtube.com" ||
      host === "www.youtube.com" ||
      host === "m.youtube.com" ||
      host === "youtu.be" ||
      host === "youtube-nocookie.com" ||
      host === "www.youtube-nocookie.com"
    );
  } catch {
    return false;
  }
}

function isConcretePlayableUrl(url) {
  if (!shouldHandleUrl(url)) return false;
  const parts = parseUrlParts(url);
  if (!parts) return false;
  return (
    isLikelyManifestUrl(url) ||
    isLikelyDirectMediaUrl(url) ||
    (parts.host === "hanime-cdn.com" &&
      /\.(m3u8|mpd|mp4|webm|m4s|ts)$/i.test(parts.path)) ||
    (parts.host.includes("googlevideo.com") && /videoplayback/i.test(parts.href)) ||
    (parts.host.includes("cloudfront.net") &&
      /\.(m3u8|mpd|mp4|webm|m4s|ts)$/i.test(parts.path)) ||
    /(?:manifest|master\.m3u8|playlist\.m3u8)/i.test(parts.path)
  );
}

function isLikelyEmbedPageUrl(url) {
  if (!shouldHandleUrl(url)) return false;
  const parts = parseUrlParts(url);
  if (!parts) return false;
  return (
    /\/(?:embed|player|watch|video|videos|e)\//i.test(parts.path) ||
    /(?:vidara\.so)$/i.test(parts.host)
  );
}

function isInterestingMediaMime(mime) {
  if (!mime || typeof mime !== "string") return false;
  return (
    /^video\//i.test(mime) ||
    /^audio\//i.test(mime) ||
    /application\/(?:vnd\.apple\.mpegurl|x-mpegurl|dash\+xml)/i.test(mime)
  );
}

function normalizeForWebRequestDedupe(url) {
  try {
    const parsed = new URL(url);
    return `${parsed.origin}${parsed.pathname}`;
  } catch {
    return url;
  }
}

function shouldCaptureByUrl(url) {
  if (!shouldHandleUrl(url)) return false;
  if (isLikelySegmentUrl(url)) return false;
  return (
    isLikelyManifestUrl(url) ||
    /\.(mp4|mkv|webm|mov|m4v|mp3|m4a|aac|flac|wav|ogg|opus|weba)(?:$|[?#])/i.test(url) ||
    /(?:googlevideo\.com\/videoplayback|manifest|master\.m3u8|playlist\.m3u8)/i.test(url)
  );
}

function shouldCaptureWebRequest(url, mime) {
  if (!shouldHandleUrl(url)) return false;
  if (isLikelySegmentUrl(url)) return false;
  if (shouldCaptureByUrl(url)) return true;
  return isInterestingMediaMime(mime || "");
}

function pruneWebRequestCaptureDedupe(now) {
  for (const [key, ts] of recentWebRequestCaptures.entries()) {
    if (now - ts > WEBREQUEST_CAPTURE_DEDUPE_WINDOW_MS) {
      recentWebRequestCaptures.delete(key);
    }
  }
}

function markWebRequestCaptured(url) {
  const now = Date.now();
  pruneWebRequestCaptureDedupe(now);
  const dedupeKey = normalizeForWebRequestDedupe(url);
  const seen = recentWebRequestCaptures.get(dedupeKey);
  if (seen && now - seen < WEBREQUEST_CAPTURE_DEDUPE_WINDOW_MS) {
    return false;
  }
  recentWebRequestCaptures.set(dedupeKey, now);
  return true;
}

function extractContentTypeHeader(headers) {
  if (!Array.isArray(headers)) return "";
  const match = headers.find((h) => String(h?.name || "").toLowerCase() === "content-type");
  return String(match?.value || "").split(";")[0].trim().toLowerCase();
}

function buildWebRequestHeaders(details) {
  const ref = details?.initiator || details?.documentUrl || "";
  if (shouldHandleUrl(ref)) {
    return { Referer: ref };
  }
  return null;
}

function rememberPlayableForTab(details, url, mime) {
  const tabId = details?.tabId;
  if (typeof tabId !== "number" || tabId < 0) return;
  if (isLikelySegmentUrl(url)) return;

  const now = Date.now();
  const score = scorePlayableCandidate(url, mime || "");
  if (score <= 0) return;

  const key = normalizeForWebRequestDedupe(url);
  const existing = recentPlayableByTab.get(tabId) || [];
  const next = existing
    .filter((entry) => now - entry.at <= RECENT_PLAYABLE_BY_TAB_WINDOW_MS && entry.key !== key)
    .concat([
      {
        key,
        url,
        at: now,
        score,
        mime: mime || "",
        initiator: details?.initiator || "",
        documentUrl: details?.documentUrl || "",
        origin: safeOrigin(url),
      },
    ])
    .sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      return b.at - a.at;
    })
    .slice(0, 12);
  recentPlayableByTab.set(tabId, next);
}

function recentPlayableForTab(tabId, preferredReferrer) {
  const fresh = rankedPlayableEntriesForTab(tabId, preferredReferrer);
  if (!fresh.length) return null;
  recentPlayableByTab.set(tabId, fresh.slice(0, 12));
  return fresh[0].url;
}

function rankedPlayableEntriesForTab(tabId, preferredReferrer) {
  if (typeof tabId !== "number" || tabId < 0) return null;
  const entries = recentPlayableByTab.get(tabId);
  if (!Array.isArray(entries) || entries.length === 0) return [];

  const now = Date.now();
  const preferredOrigin = safeOrigin(preferredReferrer || "");
  const fresh = entries
    .filter((entry) => now - entry.at <= RECENT_PLAYABLE_BY_TAB_WINDOW_MS)
    .sort((a, b) => {
      const aFrameBonus =
        preferredReferrer && (a.documentUrl === preferredReferrer || a.initiator === preferredOrigin)
          ? 120
          : preferredOrigin && a.origin === preferredOrigin
            ? 60
            : 0;
      const bFrameBonus =
        preferredReferrer && (b.documentUrl === preferredReferrer || b.initiator === preferredOrigin)
          ? 120
          : preferredOrigin && b.origin === preferredOrigin
            ? 60
            : 0;
      const aEffective = a.score + aFrameBonus;
      const bEffective = b.score + bFrameBonus;
      if (bEffective !== aEffective) return bEffective - aEffective;
      return b.at - a.at;
    });
  if (!fresh.length) {
    recentPlayableByTab.delete(tabId);
    return [];
  }
  return fresh;
}

async function setLastScanDebug(debugInfo) {
  await chrome.storage.session.set({ [LAST_SCAN_DEBUG_KEY]: debugInfo });
}

function sendWebRequestCapture(details, mime) {
  const url = details?.url || "";
  if (!shouldCaptureWebRequest(url, mime)) return;
  if (!markWebRequestCaptured(url)) return;
  rememberPlayableForTab(details, url, mime || "");
}

function classifyCapture(payload) {
  const url = payload?.url || "";
  const rawMediaUrl = payload?.raw_media_url || payload?.rawMediaUrl || "";
  const mime = payload?.mime || "";

  if (/^blob:/i.test(rawMediaUrl) || /^blob:/i.test(url)) {
    return "blob_backed_media";
  }

  if (
    payload?.source === "chromium-context-media" ||
    payload?.source === "chromium-downloads-api" ||
    /^video\//i.test(mime) ||
    /^audio\//i.test(mime) ||
    /^application\/octet-stream$/i.test(mime) ||
    isLikelyDirectMediaUrl(url) ||
    isLikelyDownloadableFileUrl(url)
  ) {
    return "direct_media_url";
  }

  return "page_url";
}

function inferBrowserConfidence(payload) {
  const url = payload?.url || "";
  const originalUrl = payload?.original_url || "";
  const rawMediaUrl = payload?.raw_media_url || payload?.rawMediaUrl || "";
  const mime = payload?.mime || "";
  const referrer = payload?.referrer || "";
  const candidateUrl = url || rawMediaUrl || originalUrl;

  if (isYouTubePageUrl(referrer) && isConcretePlayableUrl(candidateUrl)) {
    return "ambiguous_media";
  }
  if (isLikelyManifestUrl(candidateUrl)) {
    return "strong_manifest";
  }
  if (
    payload?.source === "chromium-downloads-api" ||
    /^application\/(?:octet-stream|vnd\.apple\.mpegurl|x-mpegurl|dash\+xml)/i.test(mime) ||
    isLikelyDirectMediaUrl(candidateUrl) ||
    isLikelyDownloadableFileUrl(candidateUrl)
  ) {
    return "strong_direct";
  }
  if (payload?.source === "chromium-context-page" || payload?.capture_type === "page_url") {
    return "page";
  }
  return "ambiguous_media";
}

function normalizeCapturePayload(payload) {
  const capture_type = payload.capture_type || classifyCapture(payload);
  const normalized = {
    ...payload,
    capture_type,
    original_url: payload.original_url || payload.url || null,
    browser_confidence: payload.browser_confidence || inferBrowserConfidence({ ...payload, capture_type }),
  };
  return normalized;
}

async function sendCapture(payload) {
  try {
    const normalizedPayload = normalizeCapturePayload(await enrichCaptureRequestContext(payload));
    const requestId =
      normalizedPayload.request_id ||
      `capture-${normalizedPayload.source || "unknown"}-${Date.now()}-${Math.random()
        .toString(36)
        .slice(2, 8)}`;
    const response = await nativeTransport.request({
      action: "capture",
      capture_type: normalizedPayload.capture_type,
      request_id: requestId,
      wait_for_ack: normalizedPayload.wait_for_ack !== false,
      sent_at_ms: Date.now(),
      ...normalizedPayload,
    });
    if (!response?.ok) {
      console.warn("[VelocityDL] Native host returned error:", response?.message);
    }
    return response || { ok: false, message: "no response" };
  } catch (err) {
    console.warn("[VelocityDL] Native host communication failed:", err);
    return { ok: false, message: String(err?.message || err || "native host unavailable") };
  }
}

async function enrichCaptureRequestContext(payload) {
  const url = payload?.url || payload?.raw_media_url || payload?.original_url || "";
  const tabId = Number.isInteger(payload?.tab_id) ? payload.tab_id : -1;
  const captured = requestContextStore.findBest(url, tabId);
  const combinedHeaders = sanitizeRequestHeaders({
    ...(captured?.headers || {}),
    ...(payload?.headers || {}),
  });
  let cookies = [];
  if (shouldHandleUrl(url) && typeof chrome.cookies?.getAll === "function") {
    try {
      cookies = await chrome.cookies.getAll({ url });
    } catch (error) {
      console.warn("[VelocityDL] Failed to refresh URL-scoped cookies:", error);
    }
  }
  const headers = mergeSessionCookies(combinedHeaders, cookies);
  const requestBody = captured?.request_body || payload?.request_body || null;
  return {
    ...payload,
    headers: Object.keys(headers).length ? headers : null,
    request_method: captured?.request_method || payload?.request_method || "GET",
    request_body: requestBody?.encoding === "unavailable" ? null : requestBody,
    request_body_unavailable: requestBody?.encoding === "unavailable",
    network_request_id: captured?.request_id || payload?.network_request_id || null,
    tab_id: captured?.tab_id ?? (tabId >= 0 ? tabId : null),
    frame_id: captured?.frame_id ?? payload?.frame_id ?? null,
    initiator: captured?.initiator || payload?.initiator || null,
    document_url: captured?.document_url || payload?.document_url || null,
    redirect_chain: captured?.redirect_chain || payload?.redirect_chain || [],
    context_captured_at_ms: captured?.context_captured_at_ms || Date.now(),
  };
}

async function setLastHeartbeatDebug(debugInfo) {
  await chrome.storage.session.set({ [LAST_HEARTBEAT_DEBUG_KEY]: debugInfo });
}

async function pingNativeHost() {
  try {
    console.log("[VelocityDL] pingNativeHost -> sending");
    const response = await nativeTransport.request({
      action: "ping",
    });
    console.log("[VelocityDL] pingNativeHost <- response", response);
    if (response?.ok === true) {
      return { ok: true, message: "connected" };
    }
    return { ok: false, message: response?.message || "native host error" };
  } catch (err) {
    console.warn("[VelocityDL] pingNativeHost failed", err);
    return { ok: false, message: String(err?.message || err || "native host unavailable") };
  }
}

async function fetchHostPreferences() {
  try {
    const response = await nativeTransport.request({
      action: "get_preferences",
    });
    if (response?.ok !== true) return null;
    return {
      acceptBrowserCaptures: response.accept_browser_download_requests !== false,
      takeoverAllDownloads: response.browser_takeover_all_downloads !== false,
    };
  } catch (err) {
    return null;
  }
}

async function applyHostPreferences(reason = "startup") {
  const prefs = await fetchHostPreferences();
  if (!prefs) return false;

  const current = await chrome.storage.local.get(DEFAULT_SETTINGS);
  const next = {
    ...current,
    takeoverAllDownloads: prefs.takeoverAllDownloads,
  };

  await chrome.storage.local.set(next);
  if (reason === "startup" || reason === "install") {
    queueRebuildContextMenus(next.showContextMenu);
  }
  return true;
}

async function sendHeartbeat(reason = "background") {
  try {
    console.log("[VelocityDL] sendHeartbeat -> sending", {
      reason,
      runtimeId: chrome.runtime.id,
      version: chrome.runtime.getManifest().version || "unknown",
    });
    const response = await nativeTransport.request({
      action: "heartbeat",
      browser: "chromium",
      extension_version: chrome.runtime.getManifest().version || "unknown",
      runtime_id: chrome.runtime.id,
      source: `extension-heartbeat:${reason}`,
      sent_at_ms: Date.now(),
    });
    console.log("[VelocityDL] sendHeartbeat <- response", response);
    await setLastHeartbeatDebug({
      at: Date.now(),
      ok: response?.ok === true,
      message: response?.message || "",
      reason,
      runtimeId: chrome.runtime.id,
      extensionVersion: chrome.runtime.getManifest().version || "unknown",
      response: response || null,
    });
    if (response?.ok === true) {
      return { ok: true, message: "heartbeat sent" };
    }
    return { ok: false, message: response?.message || "heartbeat failed" };
  } catch (err) {
    console.warn("[VelocityDL] sendHeartbeat failed", { reason, error: String(err?.message || err || "") });
    await setLastHeartbeatDebug({
      at: Date.now(),
      ok: false,
      message: String(err?.message || err || "heartbeat unavailable"),
      reason,
      runtimeId: chrome.runtime.id,
      extensionVersion: chrome.runtime.getManifest().version || "unknown",
      response: null,
    });
    return { ok: false, message: String(err?.message || err || "heartbeat unavailable") };
  }
}

async function scheduleHeartbeatAlarm() {
  try {
    await chrome.alarms.clear(HEARTBEAT_ALARM);
  } catch {}
  chrome.alarms.create(HEARTBEAT_ALARM, {
    delayInMinutes: 0.2,
    periodInMinutes: HEARTBEAT_PERIOD_MINUTES,
  });
  try {
    await chrome.alarms.clear(SESSION_REFRESH_ALARM);
  } catch {}
  chrome.alarms.create(SESSION_REFRESH_ALARM, {
    delayInMinutes: 0.1,
    periodInMinutes: 0.5,
  });
}

async function syncSessionRefreshRequests() {
  let response;
  try {
    response = await nativeTransport.request({ action: "get_session_refresh_requests" });
  } catch {
    return;
  }
  const requests = Array.isArray(response?.refresh_requests) ? response.refresh_requests : [];
  await Promise.all(requests.slice(0, 32).map(async (request) => {
    if (!request?.refresh_id || !shouldHandleUrl(request?.url)) return;
    const captured = requestContextStore.findBest(request.url, -1);
    let cookies = [];
    try {
      cookies = typeof chrome.cookies?.getAll === "function"
        ? await chrome.cookies.getAll({ url: request.url })
        : [];
    } catch {}
    const refreshHeaders = mergeSessionCookies(captured?.headers || {}, cookies);
    await nativeTransport.request({
      action: "session_refresh_response",
      refresh_id: request.refresh_id,
      refresh_headers: refreshHeaders,
      sent_at_ms: Date.now(),
    });
  }));
}

async function toggleScanOnTab(tab) {
  if (!tab?.id || !tab.url || !/^https?:\/\//i.test(tab.url)) {
    return { ok: false, message: "Open a normal web page first." };
  }

  try {
    const nextActive = !(await isScanActiveForTab(tab.id));
    await setScanActiveForTab(tab.id, nextActive);
    await applyScanStateToTab(tab.id, nextActive);
    return { ok: true, active: nextActive };
  } catch (err) {
    console.warn("[VelocityDL] Failed to toggle scan overlay:", err);
    return { ok: false, message: "Failed to toggle scan overlay." };
  }
}

async function handleBrowserDownload(item) {
  const settings = await getSettings();
  if (!settings.takeoverAllDownloads) return;
  if (!shouldHandleUrl(item.url)) return;

  pendingBrowserDownloads.set(item.id, {
    id: item.id,
    createdAt: Date.now(),
    attempts: 0,
    url: item.finalUrl || item.url,
    originalUrl: item.url,
    filename: item.filename || null,
    mime: item.mime || null,
    referrer: item.referrer || null,
  });

  setTimeout(() => {
    flushPendingBrowserDownload(item.id);
  }, 700);
}

async function flushPendingBrowserDownload(id) {
  const pending = pendingBrowserDownloads.get(id);
  if (!pending) return;

  const candidateUrl = pending.url || pending.originalUrl || "";
  const hasGoodDirectUrl =
    isLikelyDirectMediaUrl(candidateUrl) ||
    isLikelyDownloadableFileUrl(candidateUrl);
  const hasStrongFilenameSignal = filenameLooksDownloadable(pending.filename || "");

  if (!hasGoodDirectUrl && hasStrongFilenameSignal && pending.attempts < 8) {
    pending.attempts += 1;
    setTimeout(() => {
      flushPendingBrowserDownload(id);
    }, 400);
    return;
  }

  pendingBrowserDownloads.delete(id);

  if (!hasGoodDirectUrl) {
    return;
  }

  let headers = null;
  try {
    const cookies = typeof chrome.cookies?.getAll === "function"
      ? await chrome.cookies.getAll({ url: candidateUrl })
      : [];
    headers = buildBrowserTakeoverHeaders({
      referrer: pending.referrer || null,
      cookies,
    });
  } catch (error) {
    console.warn("[VelocityDL] Failed to collect browser takeover session headers:", error);
  }

  const requestId = `downloads-${id}-${Date.now()}`;
  const handoff = await sendCapture({
    url: candidateUrl,
    original_url: pending.originalUrl || candidateUrl,
    filename: pending.filename || null,
    mime: pending.mime || null,
    referrer: pending.referrer || null,
    source: "chromium-downloads-api",
    headers,
    request_id: requestId,
    wait_for_ack: true,
  });

  if (handoff?.accepted === true || handoff?.ok === true) {
    try {
      await chrome.downloads.cancel(id);
      await chrome.downloads.erase({ id });
    } catch (e) {
      // Some downloads cannot be cancelled quickly enough; ignore gracefully.
    }
  } else {
    console.warn("[VelocityDL] Browser fallback retained download:", handoff?.message || "handoff rejected");
  }
}

chrome.runtime.onInstalled.addListener(async () => {
  console.log("[VelocityDL] onInstalled");
  const settings = await getSettings();
  await chrome.storage.local.set(settings);
  await applyHostPreferences("install");
  await chrome.storage.session.set({ [ACTIVE_SCAN_TABS_KEY]: [] });
  queueRebuildContextMenus(settings.showContextMenu);
  await scheduleHeartbeatAlarm();
  await sendHeartbeat("installed");
  await syncSessionRefreshRequests();
});
chrome.runtime.onStartup.addListener(async () => {
  console.log("[VelocityDL] onStartup");
  const settings = await getSettings();
  await applyHostPreferences("startup");
  await initializeActiveScanTabs();
  queueRebuildContextMenus(settings.showContextMenu);
  await scheduleHeartbeatAlarm();
  await sendHeartbeat("startup");
  await syncSessionRefreshRequests();
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm?.name === HEARTBEAT_ALARM) {
    console.log("[VelocityDL] alarm fired", alarm.name);
    await sendHeartbeat("alarm");
    await syncSessionRefreshRequests();
    return;
  }
  if (alarm?.name === SESSION_REFRESH_ALARM) {
    await syncSessionRefreshRequests();
  }
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  await clearScanStateOnTab(tabId);
});

chrome.webNavigation.onCommitted.addListener(async (details) => {
  if (details?.tabId < 0 || !/^https?:\/\//i.test(details?.url || "")) return;
  if (details.frameId === 0) {
    recentPlayableByTab.delete(details.tabId);
  }
  if (!(await isScanActiveForTab(details.tabId))) return;
  await applyScanStateToTab(details.tabId, true, details.frameId);
});

chrome.downloads.onCreated.addListener((item) => {
  handleBrowserDownload(item);
});

chrome.downloads.onChanged.addListener((delta) => {
  const pending = pendingBrowserDownloads.get(delta.id);
  if (!pending) return;

  if (delta.finalUrl?.current && shouldHandleUrl(delta.finalUrl.current)) {
    pending.url = delta.finalUrl.current;
  }
  if (delta.filename?.current) {
    const leaf = delta.filename.current.split(/[\\/]/).pop();
    if (leaf) {
      pending.filename = leaf;
    }
  }

  if (delta.state?.current === "complete" || delta.state?.current === "interrupted") {
    flushPendingBrowserDownload(delta.id);
  }
});

chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    requestContextStore.onBeforeRequest(details);
    if (details?.tabId === -1) return;
    sendWebRequestCapture(details, "");
  },
  { urls: ["<all_urls>"] },
  ["requestBody"]
);

chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => requestContextStore.onBeforeSendHeaders(details),
  { urls: ["<all_urls>"] },
  ["requestHeaders", "extraHeaders"]
);

chrome.webRequest.onBeforeRedirect.addListener(
  (details) => requestContextStore.onBeforeRedirect(details),
  { urls: ["<all_urls>"] }
);

chrome.webRequest.onCompleted.addListener(
  (details) => requestContextStore.onCompleted(details),
  { urls: ["<all_urls>"] }
);

chrome.webRequest.onErrorOccurred.addListener(
  (details) => requestContextStore.onCompleted(details),
  { urls: ["<all_urls>"] }
);

chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    if (details?.tabId === -1) return;
    const mime = extractContentTypeHeader(details.responseHeaders);
    if (!isInterestingMediaMime(mime)) return;
    sendWebRequestCapture(details, mime);
  },
  { urls: ["<all_urls>"], types: ["media", "xmlhttprequest", "other"] },
  ["responseHeaders"]
);

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "vdl-download-link" && shouldHandleUrl(info.linkUrl)) {
    await sendCapture({
      url: info.linkUrl,
      original_url: info.linkUrl,
      referrer: info.pageUrl || null,
      source: "chromium-context-link",
      tab_id: tab?.id ?? null,
      headers: info.pageUrl ? { Referer: info.pageUrl } : null,
    });
    return;
  }

  if (info.menuItemId === "vdl-download-page" && tab?.url && shouldHandleUrl(tab.url)) {
    await sendCapture({
      url: tab.url,
      original_url: tab.url,
      source: "chromium-context-page",
      tab_id: tab?.id ?? null,
      headers: tab.url ? { Referer: tab.url } : null,
    });
    return;
  }

  if (info.menuItemId === "vdl-download-media" && shouldHandleUrl(info.srcUrl)) {
    await sendCapture({
      url: info.srcUrl,
      original_url: info.srcUrl,
      referrer: info.pageUrl || null,
      source: "chromium-context-media",
      tab_id: tab?.id ?? null,
      headers: info.pageUrl ? { Referer: info.pageUrl } : null,
    });
  }
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (Object.prototype.hasOwnProperty.call(changes, "showContextMenu")) {
    queueRebuildContextMenus(!!changes.showContextMenu.newValue);
  }
});

chrome.action.onClicked.addListener(async (tab) => {
  await toggleScanOnTab(tab);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "vdl_media_observed") {
    const tabId = sender?.tab?.id;
    const frameId = sender?.frameId ?? 0;
    const event = message.event || {};
    const snapshot = observedMediaStore.observe({ ...event, tabId, frameId });
    if (snapshot?.preferred_url && snapshot.preferred_url === event.url) {
      rememberPlayableForTab(
        {
          tabId,
          frameId,
          initiator: sender?.origin || safeOrigin(sender?.tab?.url || ""),
          documentUrl: sender?.url || sender?.tab?.url || "",
        },
        event.url,
        event.mime || ""
      );
    }
    sendResponse({ ok: true });
    return false;
  }

  if (message?.type === "vdl_popup_get_state") {
    (async () => {
      console.log("[VelocityDL] popup requested state");
      const settings = await getSettings();
      const native = await pingNativeHost();
      const heartbeat = await sendHeartbeat("popup_state");
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const activeTab = tabs?.[0];
      const scanActive = activeTab?.id ? await isScanActiveForTab(activeTab.id) : false;
      sendResponse({
        ok: true,
        settings,
        native,
        heartbeat,
        scan: {
          active: scanActive,
        },
        runtimeId: chrome.runtime.id,
        extensionVersion: chrome.runtime.getManifest().version || "unknown",
      });
    })();
    return true;
  }

  if (message?.type === "vdl_popup_get_debug") {
    (async () => {
      const debug = (await chrome.storage.session.get(LAST_SCAN_DEBUG_KEY))?.[LAST_SCAN_DEBUG_KEY] || null;
      const heartbeat = (await chrome.storage.session.get(LAST_HEARTBEAT_DEBUG_KEY))?.[LAST_HEARTBEAT_DEBUG_KEY] || null;
      sendResponse({ ok: true, debug, heartbeat });
    })();
    return true;
  }

  if (message?.type === "vdl_popup_update_settings") {
    (async () => {
      const next = {
        takeoverAllDownloads: !!message.takeoverAllDownloads,
        showContextMenu: !!message.showContextMenu,
        scanCaptureMode: normalizeScanCaptureMode(message.scanCaptureMode),
      };
      await chrome.storage.local.set(next);
      queueRebuildContextMenus(next.showContextMenu);
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (message?.type === "vdl_popup_toggle_scan") {
    (async () => {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const tab = tabs?.[0];
      const result = await toggleScanOnTab(tab);
      sendResponse(result);
    })();
    return true;
  }

  if (message?.type === "vdl_scan_overlay_get_state") {
    (async () => {
      sendResponse({
        ok: true,
        active: await isScanActiveForTab(sender?.tab?.id),
      });
    })();
    return true;
  }

  if (message?.type !== "vdl_capture_from_page") return false;

  (async () => {
    try {
      const scanSettings = await getSettings();
      const senderTabId = sender?.tab?.id;
      const referrer = message.referrer || sender?.tab?.url || null;
      const rawMediaUrl = message.rawMediaUrl || null;
      let resolvedUrl = message.url;
      let resolvedRawMediaUrl = rawMediaUrl;
      const observedMedia = observedMediaStore.snapshot(senderTabId, sender?.frameId ?? null);
      const rankedCandidates = rankedPlayableEntriesForTab(senderTabId, referrer).slice(0, 5);
      if (
        observedMedia?.preferred_url &&
        !rankedCandidates.some((candidate) => candidate.url === observedMedia.preferred_url)
      ) {
        rankedCandidates.unshift({
          url: observedMedia.preferred_url,
          score: 260,
          initiator: safeOrigin(referrer || ""),
          documentUrl: referrer || "",
          mime: "",
        });
      }

      const directRawMediaUrl =
        typeof rawMediaUrl === "string" && isConcretePlayableUrl(rawMediaUrl) ? rawMediaUrl : null;
      const scanCaptureSelection = chooseResolvedScanCapture({
        source: message?.source,
        scanCaptureMode: scanSettings.scanCaptureMode,
        messageUrl: resolvedUrl,
        referrer,
        directRawMediaUrl,
        rankedCandidates,
      });
      resolvedUrl = scanCaptureSelection.resolvedUrl;
      resolvedRawMediaUrl = scanCaptureSelection.resolvedRawMediaUrl;

      await setLastScanDebug({
        at: Date.now(),
        tabId: senderTabId ?? null,
        referrer,
        inputUrl: message.url || null,
        inputRawMediaUrl: rawMediaUrl || null,
        resolvedUrl,
        resolvedRawMediaUrl: resolvedRawMediaUrl || null,
        usedRecentPlayable: scanCaptureSelection.usedRecentPlayable,
        topCandidates: rankedCandidates.map((entry) => ({
          url: entry.url,
          score: entry.score,
          initiator: entry.initiator,
          documentUrl: entry.documentUrl,
          mime: entry.mime,
        })),
      });

      const weakScanCaptureDecision = shouldRejectWeakScanCapture({
        source: message?.source,
        referrer,
        resolvedUrl,
        resolvedRawMediaUrl,
        hasConcreteResolvedUrl: isConcretePlayableUrl(resolvedUrl),
        hasConcreteRawMediaUrl: isConcretePlayableUrl(resolvedRawMediaUrl || ""),
        hasTopCandidate: rankedCandidates.length > 0,
        isLikelyEmbedPage: isLikelyEmbedPageUrl(resolvedUrl),
        rawMediaWasBlob: /^blob:/i.test(rawMediaUrl || ""),
      });

      if (weakScanCaptureDecision.reject) {
        await setLastScanDebug({
          at: Date.now(),
          tabId: senderTabId ?? null,
          referrer,
          inputUrl: message.url || null,
          inputRawMediaUrl: rawMediaUrl || null,
          resolvedUrl,
          resolvedRawMediaUrl: resolvedRawMediaUrl || null,
          usedRecentPlayable: scanCaptureSelection.usedRecentPlayable,
          rejectionReason: weakScanCaptureDecision.reason,
          topCandidates: rankedCandidates.map((entry) => ({
            url: entry.url,
            score: entry.score,
            initiator: entry.initiator,
            documentUrl: entry.documentUrl,
            mime: entry.mime,
          })),
        });
        sendResponse({
          ok: false,
          message:
            weakScanCaptureDecision.reason === "weak_blob_scan_capture"
              ? "Only a blob-backed player URL was detected. Start playback, wait a few seconds for the real media request, then try capture again or use Deep Sniff."
              : "No direct video stream detected yet. Start playback, wait a few seconds, then try capture again.",
        });
        return;
      }

      if (!shouldHandleUrl(resolvedUrl)) {
        sendResponse({ ok: false, message: "invalid url" });
        return;
      }

      let headers = null;
      try {
        const cookies = typeof chrome.cookies?.getAll === "function"
          ? await chrome.cookies.getAll({ url: resolvedUrl })
          : [];
        headers = buildBrowserTakeoverHeaders({
          referrer,
          cookies,
        });
      } catch (error) {
        console.warn("[VelocityDL] Failed to collect scan capture session headers:", error);
      }

      const payload = {
        url: resolvedUrl,
        original_url: message.url || resolvedUrl,
        filename: message.filename || null,
        mime: message.mime || null,
        raw_media_url: resolvedRawMediaUrl,
        referrer,
        source: "chromium-scan-overlay",
        tab_id: senderTabId ?? null,
        frame_id: sender?.frameId ?? null,
        media_context: observedMedia,
        scan_auto_open_quality_picker: scanSettings.scanCaptureMode === "quality_picker",
        scan_capture_mode: scanSettings.scanCaptureMode,
        headers: headers || resolvedRawMediaUrl
          ? {
              ...(headers || {}),
              ...(resolvedRawMediaUrl
                ? { "X-VDL-Raw-Media-Url": String(resolvedRawMediaUrl) }
                : {}),
            }
          : null,
      };

      await sendCapture({
        ...payload,
        capture_type: classifyCapture(payload),
      });
      sendResponse({ ok: true });
    } catch (err) {
      sendResponse({ ok: false, message: String(err) });
    }
  })();

  return true;
});
